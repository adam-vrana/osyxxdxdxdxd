#ifndef CHECKER_H
#define CHECKER_H

// function for checking float numbers
int check_numbers();

#endif