#ifndef CHECKER_H
#define CHECKER_H

// function for checking integer numbers
int check_numbers();

#endif