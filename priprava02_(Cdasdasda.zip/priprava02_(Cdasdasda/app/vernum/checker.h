#ifndef CHECKER_H
#define CHECKER_H

// function for checking numbers (implemented differently in each library)
int check_numbers();

#endif