#ifndef GENERATOR_H
#define GENERATOR_H

// function for generating integers - from gen_int.c
void generate_integers(int M, int N);

// function for generating floats - from gen_float.c
void generate_floats(int M, int N);

void generate_hexa(int M, int N);

void generate_bin(int M, int N);
#endif